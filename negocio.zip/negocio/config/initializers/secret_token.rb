# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Negocio::Application.config.secret_token = '1873f5a3a19e80d2bed48fc72d67a3da258e6e0b1f3b54a37e8d8d822b3ff949fb0d4c58729e2372b08dd43dc27e8ee4535647d0c8b8d8e29ced2bfbf8d3e618'
