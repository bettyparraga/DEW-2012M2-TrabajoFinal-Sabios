require 'test_helper'

class PlansHelperTest < ActionView::TestCase
end
