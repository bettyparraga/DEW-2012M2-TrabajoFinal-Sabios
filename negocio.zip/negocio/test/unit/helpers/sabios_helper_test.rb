require 'test_helper'

class SabiosHelperTest < ActionView::TestCase
end
