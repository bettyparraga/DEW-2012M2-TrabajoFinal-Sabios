require 'test_helper'

class SabioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
