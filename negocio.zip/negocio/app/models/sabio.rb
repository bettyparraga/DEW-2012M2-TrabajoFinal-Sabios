class Sabio < ActiveRecord::Base
  has_many :plans
end
